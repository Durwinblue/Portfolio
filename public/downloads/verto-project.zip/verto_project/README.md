# Verto Car Rental Platform

This archive contains a local PHP/MySQL implementation of **Verto**, a car rental company website delivered as a university graduation project.

## Contents
- `code/` – Selected PHP templates and assets that power the marketing and booking experience
- `screenshots/` – Exported previews of key pages (home, vehicle listings, booking flow)

## Getting Started
1. Copy the contents of the `code/` directory into your local PHP environment (e.g., XAMPP, Laragon, or a standard LAMP stack).
2. Import the `verto.sql` schema into MySQL to provision the required tables.
3. Update the database credentials in `code/config.php` to match your environment.
4. Navigate to the project in your browser (e.g., `http://localhost/verto`).

> **Note:** This project is optimised for a traditional server-rendered workflow and requires PHP 8+ with MySQL.

Enjoy exploring the project!

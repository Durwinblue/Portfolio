CREATE TABLE IF NOT EXISTS vehicles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  daily_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  image_path VARCHAR(255) DEFAULT NULL,
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  display_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO vehicles (name, daily_rate, image_path, is_featured, display_order) VALUES
('Audi Q7', 129.00, '/verto/assets/images/audi-q7.jpg', 1, 1),
('BMW 5 Series', 119.00, '/verto/assets/images/bmw-5.jpg', 1, 2),
('Mercedes-Benz GLC', 135.00, '/verto/assets/images/mercedes-glc.jpg', 1, 3);

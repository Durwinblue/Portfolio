<?php
require_once __DIR__ . '/config.php';

// Fetch featured vehicles
$stmt = $pdo->query('SELECT id, name, daily_rate, image_path FROM vehicles WHERE is_featured = 1 ORDER BY display_order');
$vehicles = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verto Car Rental</title>
    <link rel="stylesheet" href="/verto/assets/styles.css">
  </head>
  <body>
    <header class="hero">
      <h1>Verto Car Rental</h1>
      <p>Premium vehicles, flexible plans, and concierge-level support.</p>
      <a class="cta" href="/verto/reservations.php">Reserve a car</a>
    </header>

    <section class="section">
      <h2>Featured Vehicles</h2>
      <div class="grid">
        <?php foreach ($vehicles as $vehicle): ?>
          <article class="card">
            <img src="<?= htmlspecialchars($vehicle['image_path']) ?>" alt="<?= htmlspecialchars($vehicle['name']) ?>">
            <h3><?= htmlspecialchars($vehicle['name']) ?></h3>
            <p class="rate">$<?= number_format($vehicle['daily_rate'], 2) ?> / day</p>
          </article>
        <?php endforeach; ?>
      </div>
    </section>

    <footer class="footer">
      <p>© <?= date('Y') ?> Verto Car Rental. All rights reserved.</p>
    </footer>
  </body>
</html>

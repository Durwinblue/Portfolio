# Flavoro Online Restaurant

`Flavoro` is a PHP/MySQL powered online restaurant experience featuring an interactive menu, cart management, and reservation handling.

## Contents
- `code/` – Sample PHP views, routes, and configuration files used in the local deployment
- `screenshots/` – Visual previews of the landing page, menu browsing, and checkout flow

## Local Setup
1. Move the `code/` directory into your PHP server root (e.g., `htdocs/flavoro`).
2. Import `flavoro.sql` into your MySQL instance to seed the menu and orders tables.
3. Adjust the credentials in `code/config.php`.
4. Visit `http://localhost/flavoro` in your browser.

Happy coding and bon appétit!

<?php
require_once __DIR__ . '/config.php';

$categories = $pdo->query('SELECT id, name FROM menu_categories ORDER BY display_order')->fetchAll();
$itemsStmt = $pdo->prepare('SELECT name, description, price, image_path FROM menu_items WHERE category_id = :category ORDER BY display_order');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flavoro Restaurant</title>
    <link rel="stylesheet" href="/flavoro/assets/styles.css">
  </head>
  <body>
    <header class="hero">
      <h1>Flavoro</h1>
      <p>Crafted dishes delivered with passion.</p>
      <a class="cta" href="#menu">View Menu</a>
    </header>

    <main class="wrapper">
      <?php foreach ($categories as $category): ?>
        <section id="category-<?= $category['id'] ?>" class="menu-section">
          <h2><?= htmlspecialchars($category['name']) ?></h2>
          <div class="menu-grid">
            <?php
              $itemsStmt->execute(['category' => $category['id']]);
              foreach ($itemsStmt->fetchAll() as $item):
            ?>
              <article class="menu-card">
                <img src="<?= htmlspecialchars($item['image_path']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                <div>
                  <h3><?= htmlspecialchars($item['name']) ?></h3>
                  <p><?= htmlspecialchars($item['description']) ?></p>
                  <span class="price">$<?= number_format($item['price'], 2) ?></span>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        </section>
      <?php endforeach; ?>
    </main>
  </body>
</html>

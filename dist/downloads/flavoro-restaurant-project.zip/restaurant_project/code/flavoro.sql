CREATE TABLE IF NOT EXISTS menu_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  display_order INT UNSIGNED NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS menu_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  image_path VARCHAR(255) DEFAULT NULL,
  display_order INT UNSIGNED NOT NULL DEFAULT 0,
  FOREIGN KEY (category_id) REFERENCES menu_categories(id)
);

INSERT INTO menu_categories (name, display_order) VALUES
('Starters', 1),
('Mains', 2),
('Desserts', 3),
('Drinks', 4);

INSERT INTO menu_items (category_id, name, description, price, image_path, display_order) VALUES
(1, 'Truffle Arancini', 'Crispy risotto balls with parmesan and truffle aioli.', 8.50, '/flavoro/assets/images/truffle-arancini.jpg', 1),
(2, 'Seared Salmon', 'Pan-seared salmon with lemon butter and seasonal greens.', 19.00, '/flavoro/assets/images/seared-salmon.jpg', 1),
(3, 'Tiramisu', 'Classic Italian tiramisu with espresso and mascarpone.', 7.50, '/flavoro/assets/images/tiramisu.jpg', 1),
(4, 'Citrus Cooler', 'Sparkling citrus drink with mint and orange bitters.', 4.50, '/flavoro/assets/images/citrus-cooler.jpg', 1);
